The following files were generated for 'cs_ila1' in directory
C:\Users\Veteran\Documents\CSD FINAL\Talkboy\ipcore_dir\

XCO file generator:
   Generate an XCO file for compatibility with legacy flows.

   * cs_ila1.xco

Creates an implementation netlist:
   Creates an implementation netlist for the IP.

   * cs_ila1.cdc
   * cs_ila1.ejp
   * cs_ila1.ncf
   * cs_ila1.ngc
   * cs_ila1.v
   * cs_ila1.veo
   * cs_ila1_xmdf.tcl

IP Symbol Generator:
   Generate an IP symbol based on the current project options'.

   * cs_ila1.asy

SYM file generator:
   Generate a SYM file for compatibility with legacy flows

   * cs_ila1.sym

Generate ISE subproject:
   Create an ISE subproject for use when including this core in ISE designs

   * cs_ila1.gise
   * cs_ila1.xise

Deliver Readme:
   Readme file for the IP.

   * cs_ila1_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * cs_ila1_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

