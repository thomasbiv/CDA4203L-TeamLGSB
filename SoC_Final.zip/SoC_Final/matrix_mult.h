#ifndef __MATRIXMUL_H__
#define __MATRIXMUL_H__

#include <cmath>
#include <iostream>
#include <chrono>
using namespace std;

// Compare TB vs HW C-model and/or RTL
#define HW_COSIM

#define IN_A_ROWS 256
#define IN_A_COLS 256
#define IN_B_ROWS 256
#define IN_B_COLS 256

typedef int mat_a;
typedef int mat_b;
typedef int mat_prod;

// Prototype of top level function for C-synthesis
void matrix_mult(
    mat_a a[IN_A_ROWS][IN_A_COLS],
    mat_b b[IN_B_ROWS][IN_B_COLS],
    mat_prod prod[IN_A_ROWS][IN_B_COLS],
	int a_row_b_col
	//std::chrono::duration<float, std::ratio<1, 1000000000>> elapsed_seconds
	);

#endif // __MATRIXMUL_H__ not defined
