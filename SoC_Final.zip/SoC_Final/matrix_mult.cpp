#include "matrix_mult.h"
#include <chrono>

using namespace std;

// Goal of this function is to try to unroll a loop as much as possible to save on latency.
void matrix_mult(mat_a a[IN_A_ROWS][IN_A_COLS], mat_b b[IN_B_ROWS][IN_B_COLS], mat_prod prod[IN_A_ROWS][IN_B_COLS], int a_row_b_col)
{	
	int a_rows_b_cols = a_row_b_col;
	int k = 0, l = 0;
	if (a_rows_b_cols % 2 != 0)
	{
		int a_rows_b_cols = a_row_b_col - 1;
		int l = 1;

		for (int i = 0; i < IN_A_ROWS; i++) // Col
		{
			prod[i][0] = 0;
		}
		// Iterate over the rows of the A matrix
		for (int i = 0; i < IN_A_ROWS; i++) // Row
		{
			for (int j = 0; j < IN_B_COLS; j++) // Col
			{
				prod[i][0] += a[i][0] * b[0][j];
			}
		}


		for (int j = 0; j < IN_B_COLS; j++) // Col
		{
			prod[0][j] = 0;
		}
		// Iterate over the rows of the A matrix
		for (int i = 0; i < IN_A_ROWS; i++) // Row
		{
			for (int j = 0; j < IN_B_COLS; j++) // Col
			{
				prod[0][j] += a[i][0] * b[0][j];
			}
		}
	}
		if (a_rows_b_cols % 8 == 0)
		{
			// Iterate over the rows of the A matrix
			for (int i = 0; i < IN_A_ROWS; i += 8) // Row
			{
				// Iterate over the columns of the B matrix
				for (int j = 0; j < IN_B_COLS; j += 8) // Col
				{
					prod[i][j] = 0;
					prod[i][j+1] = 0;
					prod[i][j+2] = 0;
					prod[i][j+3] = 0;
					prod[i][j+4] = 0;
					prod[i][j+5] = 0;
					prod[i][j+6] = 0;
					prod[i][j+7] = 0;
					prod[i+1][j] = 0;
					prod[i+2][j] = 0;
					prod[i+3][j] = 0;
					prod[i+4][j] = 0;
					prod[i+5][j] = 0;
					prod[i+6][j] = 0;
					prod[i+7][j] = 0;
					prod[i+1][j+1] = 0;
					prod[i+1][j+2] = 0;
					prod[i+1][j+3] = 0;
					prod[i+1][j+4] = 0;
					prod[i+1][j+5] = 0;
					prod[i+1][j+6] = 0;
					prod[i+1][j+7] = 0;
					prod[i+2][j+1] = 0;
					prod[i+2][j+2] = 0;
					prod[i+2][j+3] = 0;
					prod[i+2][j+4] = 0;
					prod[i+2][j+5] = 0;
					prod[i+2][j+6] = 0;
					prod[i+2][j+7] = 0;
					prod[i+3][j+1] = 0;
					prod[i+3][j+2] = 0;
					prod[i+3][j+3] = 0;
					prod[i+3][j+4] = 0;
					prod[i+3][j+5] = 0;
					prod[i+3][j+6] = 0;
					prod[i+3][j+7] = 0;
					prod[i+4][j+1] = 0;
					prod[i+4][j+2] = 0;
					prod[i+4][j+3] = 0;
					prod[i+4][j+4] = 0;
					prod[i+4][j+5] = 0;
					prod[i+4][j+6] = 0;
					prod[i+4][j+7] = 0;
					prod[i+5][j+1] = 0;
					prod[i+5][j+2] = 0;
					prod[i+5][j+3] = 0;
					prod[i+5][j+4] = 0;
					prod[i+5][j+5] = 0;
					prod[i+5][j+6] = 0;
					prod[i+5][j+7] = 0;
					prod[i+6][j+1] = 0;
					prod[i+6][j+2] = 0;
					prod[i+6][j+3] = 0;
					prod[i+6][j+4] = 0;
					prod[i+6][j+5] = 0;
					prod[i+6][j+6] = 0;
					prod[i+6][j+7] = 0;
					prod[i+7][j+1] = 0;
					prod[i+7][j+2] = 0;
					prod[i+7][j+3] = 0;
					prod[i+7][j+4] = 0;
					prod[i+7][j+5] = 0;
					prod[i+7][j+6] = 0;
					prod[i+7][j+7] = 0;

					// Do the inner product of a row of A and column of B
					for (k = l; k < IN_B_ROWS; k += 8) // Product
					{
						if (k < a_rows_b_cols)
						{
							prod[i+7][j+7] += ((a[i][k] * b[k][j])   + (a[i+1][k] * b[k][j+1])   + (a[i+2][k] * b[k][j+2])   + (a[i+3][k] * b[k][j+3])   + (a[i+4][k] * b[k][j+4])   + (a[i+5][k] * b[k][j+5])   + (a[i+6][k] * b[k][j+6])   + (a[i+7][k] * b[k][j+7]));
							prod[i+7][j+6] += ((a[i][k] * b[k+1][j]) + (a[i+1][k] * b[k+1][j+1]) + (a[i+2][k] * b[k+1][j+2]) + (a[i+3][k] * b[k+1][j+3]) + (a[i+4][k] * b[k+1][j+4]) + (a[i+5][k] * b[k+1][j+5]) + (a[i+6][k] * b[k+1][j+6]) + (a[i+7][k] * b[k+1][j+7]));
							prod[i+7][j+5] += ((a[i][k] * b[k+2][j]) + (a[i+1][k] * b[k+2][j+1]) + (a[i+2][k] * b[k+2][j+2]) + (a[i+3][k] * b[k+2][j+3]) + (a[i+4][k] * b[k+2][j+4]) + (a[i+5][k] * b[k+2][j+5]) + (a[i+6][k] * b[k+2][j+6]) + (a[i+7][k] * b[k+2][j+7]));
							prod[i+7][j+4] += ((a[i][k] * b[k+3][j]) + (a[i+1][k] * b[k+3][j+1]) + (a[i+2][k] * b[k+3][j+2]) + (a[i+3][k] * b[k+3][j+3]) + (a[i+4][k] * b[k+3][j+4]) + (a[i+5][k] * b[k+3][j+5]) + (a[i+6][k] * b[k+3][j+6]) + (a[i+7][k] * b[k+3][j+7]));
							prod[i+7][j+3] += ((a[i][k] * b[k+4][j]) + (a[i+1][k] * b[k+4][j+1]) + (a[i+2][k] * b[k+4][j+2]) + (a[i+3][k] * b[k+4][j+3]) + (a[i+4][k] * b[k+4][j+4]) + (a[i+5][k] * b[k+4][j+5]) + (a[i+6][k] * b[k+4][j+6]) + (a[i+7][k] * b[k+4][j+7]));
							prod[i+7][j+2] += ((a[i][k] * b[k+5][j]) + (a[i+1][k] * b[k+5][j+1]) + (a[i+2][k] * b[k+5][j+2]) + (a[i+3][k] * b[k+5][j+3]) + (a[i+4][k] * b[k+5][j+4]) + (a[i+5][k] * b[k+5][j+5]) + (a[i+6][k] * b[k+5][j+6]) + (a[i+7][k] * b[k+5][j+7]));
							prod[i+7][j+1] += ((a[i][k] * b[k+6][j]) + (a[i+1][k] * b[k+6][j+1]) + (a[i+2][k] * b[k+6][j+2]) + (a[i+3][k] * b[k+6][j+3]) + (a[i+4][k] * b[k+6][j+4]) + (a[i+5][k] * b[k+6][j+5]) + (a[i+6][k] * b[k+6][j+6]) + (a[i+7][k] * b[k+6][j+7]));
							prod[i+7][j]   += ((a[i][k] * b[k+7][j]) + (a[i+1][k] * b[k+7][j+1]) + (a[i+2][k] * b[k+7][j+2]) + (a[i+3][k] * b[k+7][j+3]) + (a[i+4][k] * b[k+7][j+4]) + (a[i+5][k] * b[k+7][j+5]) + (a[i+6][k] * b[k+7][j+6]) + (a[i+7][k] * b[k+7][j+7]));

							prod[i+6][j+7] += ((a[i][k+1] * b[k][j])   + (a[i+1][k+1] * b[k][j+1])   + (a[i+2][k+1] * b[k][j+2])   + (a[i+3][k+1] * b[k][j+3])   + (a[i+4][k+1] * b[k][j+4])   + (a[i+5][k+1] * b[k][j+5])   + (a[i+6][k+1] * b[k][j+6])   + (a[i+7][k+1] * b[k][j+7]));
							prod[i+6][j+6] += ((a[i][k+1] * b[k+1][j]) + (a[i+1][k+1] * b[k+1][j+1]) + (a[i+2][k+1] * b[k+1][j+2]) + (a[i+3][k+1] * b[k+1][j+3]) + (a[i+4][k+1] * b[k+1][j+4]) + (a[i+5][k+1] * b[k+1][j+5]) + (a[i+6][k+1] * b[k+1][j+6]) + (a[i+7][k+1] * b[k+1][j+7]));
							prod[i+6][j+5] += ((a[i][k+1] * b[k+2][j]) + (a[i+1][k+1] * b[k+2][j+1]) + (a[i+2][k+1] * b[k+2][j+2]) + (a[i+3][k+1] * b[k+2][j+3]) + (a[i+4][k+1] * b[k+2][j+4]) + (a[i+5][k+1] * b[k+2][j+5]) + (a[i+6][k+1] * b[k+2][j+6]) + (a[i+7][k+1] * b[k+2][j+7]));
							prod[i+6][j+4] += ((a[i][k+1] * b[k+3][j]) + (a[i+1][k+1] * b[k+3][j+1]) + (a[i+2][k+1] * b[k+3][j+2]) + (a[i+3][k+1] * b[k+3][j+3]) + (a[i+4][k+1] * b[k+3][j+4]) + (a[i+5][k+1] * b[k+3][j+5]) + (a[i+6][k+1] * b[k+3][j+6]) + (a[i+7][k+1] * b[k+3][j+7]));
							prod[i+6][j+3] += ((a[i][k+1] * b[k+4][j]) + (a[i+1][k+1] * b[k+4][j+1]) + (a[i+2][k+1] * b[k+4][j+2]) + (a[i+3][k+1] * b[k+4][j+3]) + (a[i+4][k+1] * b[k+4][j+4]) + (a[i+5][k+1] * b[k+4][j+5]) + (a[i+6][k+1] * b[k+4][j+6]) + (a[i+7][k+1] * b[k+4][j+7]));
							prod[i+6][j+2] += ((a[i][k+1] * b[k+5][j]) + (a[i+1][k+1] * b[k+5][j+1]) + (a[i+2][k+1] * b[k+5][j+2]) + (a[i+3][k+1] * b[k+5][j+3]) + (a[i+4][k+1] * b[k+5][j+4]) + (a[i+5][k+1] * b[k+5][j+5]) + (a[i+6][k+1] * b[k+5][j+6]) + (a[i+7][k+1] * b[k+5][j+7]));
							prod[i+6][j+1] += ((a[i][k+1] * b[k+6][j]) + (a[i+1][k+1] * b[k+6][j+1]) + (a[i+2][k+1] * b[k+6][j+2]) + (a[i+3][k+1] * b[k+6][j+3]) + (a[i+4][k+1] * b[k+6][j+4]) + (a[i+5][k+1] * b[k+6][j+5]) + (a[i+6][k+1] * b[k+6][j+6]) + (a[i+7][k+1] * b[k+6][j+7]));
							prod[i+6][j]   += ((a[i][k+1] * b[k+7][j]) + (a[i+1][k+1] * b[k+7][j+1]) + (a[i+2][k+1] * b[k+7][j+2]) + (a[i+3][k+1] * b[k+7][j+3]) + (a[i+4][k+1] * b[k+7][j+4]) + (a[i+5][k+1] * b[k+7][j+5]) + (a[i+6][k+1] * b[k+7][j+6]) + (a[i+7][k+1] * b[k+7][j+7])); 
					
							prod[i+5][j+7] += ((a[i][k+2] * b[k][j])   + (a[i+1][k+2] * b[k][j+1])   + (a[i+2][k+2] * b[k][j+2])   + (a[i+3][k+2] * b[k][j+3])   + (a[i+4][k+2] * b[k][j+4])   + (a[i+5][k+2] * b[k][j+5])   + (a[i+6][k+2] * b[k][j+6])   + (a[i+7][k+2] * b[k][j+7]));
							prod[i+5][j+6] += ((a[i][k+2] * b[k+1][j]) + (a[i+1][k+2] * b[k+1][j+1]) + (a[i+2][k+2] * b[k+1][j+2]) + (a[i+3][k+2] * b[k+1][j+3]) + (a[i+4][k+2] * b[k+1][j+4]) + (a[i+5][k+2] * b[k+1][j+5]) + (a[i+6][k+2] * b[k+1][j+6]) + (a[i+7][k+2] * b[k+1][j+7]));
							prod[i+5][j+5] += ((a[i][k+2] * b[k+2][j]) + (a[i+1][k+2] * b[k+2][j+1]) + (a[i+2][k+2] * b[k+2][j+2]) + (a[i+3][k+2] * b[k+2][j+3]) + (a[i+4][k+2] * b[k+2][j+4]) + (a[i+5][k+2] * b[k+2][j+5]) + (a[i+6][k+2] * b[k+2][j+6]) + (a[i+7][k+2] * b[k+2][j+7]));
							prod[i+5][j+4] += ((a[i][k+2] * b[k+3][j]) + (a[i+1][k+2] * b[k+3][j+1]) + (a[i+2][k+2] * b[k+3][j+2]) + (a[i+3][k+2] * b[k+3][j+3]) + (a[i+4][k+2] * b[k+3][j+4]) + (a[i+5][k+2] * b[k+3][j+5]) + (a[i+6][k+2] * b[k+3][j+6]) + (a[i+7][k+2] * b[k+3][j+7]));
							prod[i+5][j+3] += ((a[i][k+2] * b[k+4][j]) + (a[i+1][k+2] * b[k+4][j+1]) + (a[i+2][k+2] * b[k+4][j+2]) + (a[i+3][k+2] * b[k+4][j+3]) + (a[i+4][k+2] * b[k+4][j+4]) + (a[i+5][k+2] * b[k+4][j+5]) + (a[i+6][k+2] * b[k+4][j+6]) + (a[i+7][k+2] * b[k+4][j+7]));
							prod[i+5][j+2] += ((a[i][k+2] * b[k+5][j]) + (a[i+1][k+2] * b[k+5][j+1]) + (a[i+2][k+2] * b[k+5][j+2]) + (a[i+3][k+2] * b[k+5][j+3]) + (a[i+4][k+2] * b[k+5][j+4]) + (a[i+5][k+2] * b[k+5][j+5]) + (a[i+6][k+2] * b[k+5][j+6]) + (a[i+7][k+2] * b[k+5][j+7]));
							prod[i+5][j+1] += ((a[i][k+2] * b[k+6][j]) + (a[i+1][k+2] * b[k+6][j+1]) + (a[i+2][k+2] * b[k+6][j+2]) + (a[i+3][k+2] * b[k+6][j+3]) + (a[i+4][k+2] * b[k+6][j+4]) + (a[i+5][k+2] * b[k+6][j+5]) + (a[i+6][k+2] * b[k+6][j+6]) + (a[i+7][k+2] * b[k+6][j+7]));
							prod[i+5][j]   += ((a[i][k+2] * b[k+7][j]) + (a[i+1][k+2] * b[k+7][j+1]) + (a[i+2][k+2] * b[k+7][j+2]) + (a[i+3][k+2] * b[k+7][j+3]) + (a[i+4][k+2] * b[k+7][j+4]) + (a[i+5][k+2] * b[k+7][j+5]) + (a[i+6][k+2] * b[k+7][j+6]) + (a[i+7][k+2] * b[k+7][j+7]));
					
							prod[i+4][j+7] += ((a[i][k+3] * b[k][j])   + (a[i+1][k+3] * b[k][j+1])   + (a[i+2][k+3] * b[k][j+2])   + (a[i+3][k+3] * b[k][j+3])   + (a[i+4][k+3] * b[k][j+4])   + (a[i+5][k+3] * b[k][j+5])   + (a[i+6][k+3] * b[k][j+6])   + (a[i+7][k+3] * b[k][j+7]));
							prod[i+4][j+6] += ((a[i][k+3] * b[k+1][j]) + (a[i+1][k+3] * b[k+1][j+1]) + (a[i+2][k+3] * b[k+1][j+2]) + (a[i+3][k+3] * b[k+1][j+3]) + (a[i+4][k+3] * b[k+1][j+4]) + (a[i+5][k+3] * b[k+1][j+5]) + (a[i+6][k+3] * b[k+1][j+6]) + (a[i+7][k+3] * b[k+1][j+7]));
							prod[i+4][j+5] += ((a[i][k+3] * b[k+2][j]) + (a[i+1][k+3] * b[k+2][j+1]) + (a[i+2][k+3] * b[k+2][j+2]) + (a[i+3][k+3] * b[k+2][j+3]) + (a[i+4][k+3] * b[k+2][j+4]) + (a[i+5][k+3] * b[k+2][j+5]) + (a[i+6][k+3] * b[k+2][j+6]) + (a[i+7][k+3] * b[k+2][j+7]));
							prod[i+4][j+4] += ((a[i][k+3] * b[k+3][j]) + (a[i+1][k+3] * b[k+3][j+1]) + (a[i+2][k+3] * b[k+3][j+2]) + (a[i+3][k+3] * b[k+3][j+3]) + (a[i+4][k+3] * b[k+3][j+4]) + (a[i+5][k+3] * b[k+3][j+5]) + (a[i+6][k+3] * b[k+3][j+6]) + (a[i+7][k+3] * b[k+3][j+7]));
							prod[i+4][j+3] += ((a[i][k+3] * b[k+4][j]) + (a[i+1][k+3] * b[k+4][j+1]) + (a[i+2][k+3] * b[k+4][j+2]) + (a[i+3][k+3] * b[k+4][j+3]) + (a[i+4][k+3] * b[k+4][j+4]) + (a[i+5][k+3] * b[k+4][j+5]) + (a[i+6][k+3] * b[k+4][j+6]) + (a[i+7][k+3] * b[k+4][j+7]));
							prod[i+4][j+2] += ((a[i][k+3] * b[k+5][j]) + (a[i+1][k+3] * b[k+5][j+1]) + (a[i+2][k+3] * b[k+5][j+2]) + (a[i+3][k+3] * b[k+5][j+3]) + (a[i+4][k+3] * b[k+5][j+4]) + (a[i+5][k+3] * b[k+5][j+5]) + (a[i+6][k+3] * b[k+5][j+6]) + (a[i+7][k+3] * b[k+5][j+7]));
							prod[i+4][j+1] += ((a[i][k+3] * b[k+6][j]) + (a[i+1][k+3] * b[k+6][j+1]) + (a[i+2][k+3] * b[k+6][j+2]) + (a[i+3][k+3] * b[k+6][j+3]) + (a[i+4][k+3] * b[k+6][j+4]) + (a[i+5][k+3] * b[k+6][j+5]) + (a[i+6][k+3] * b[k+6][j+6]) + (a[i+7][k+3] * b[k+6][j+7]));
							prod[i+4][j]   += ((a[i][k+3] * b[k+7][j]) + (a[i+1][k+3] * b[k+7][j+1]) + (a[i+2][k+3] * b[k+7][j+2]) + (a[i+3][k+3] * b[k+7][j+3]) + (a[i+4][k+3] * b[k+7][j+4]) + (a[i+5][k+3] * b[k+7][j+5]) + (a[i+6][k+3] * b[k+7][j+6]) + (a[i+7][k+3] * b[k+7][j+7]));

							prod[i+3][j+7] += ((a[i][k+4] * b[k][j])   + (a[i+1][k+4] * b[k][j+1])   + (a[i+2][k+4] * b[k][j+2])   + (a[i+3][k+4] * b[k][j+3])   + (a[i+4][k+4] * b[k][j+4])   + (a[i+5][k+4] * b[k][j+5])   + (a[i+6][k+4] * b[k][j+6])   + (a[i+7][k+4] * b[k][j+7]));
							prod[i+3][j+6] += ((a[i][k+4] * b[k+1][j]) + (a[i+1][k+4] * b[k+1][j+1]) + (a[i+2][k+4] * b[k+1][j+2]) + (a[i+3][k+4] * b[k+1][j+3]) + (a[i+4][k+4] * b[k+1][j+4]) + (a[i+5][k+4] * b[k+1][j+5]) + (a[i+6][k+4] * b[k+1][j+6]) + (a[i+7][k+4] * b[k+1][j+7]));
							prod[i+3][j+5] += ((a[i][k+4] * b[k+2][j]) + (a[i+1][k+4] * b[k+2][j+1]) + (a[i+2][k+4] * b[k+2][j+2]) + (a[i+3][k+4] * b[k+2][j+3]) + (a[i+4][k+4] * b[k+2][j+4]) + (a[i+5][k+4] * b[k+2][j+5]) + (a[i+6][k+4] * b[k+2][j+6]) + (a[i+7][k+4] * b[k+2][j+7]));
							prod[i+3][j+4] += ((a[i][k+4] * b[k+3][j]) + (a[i+1][k+4] * b[k+3][j+1]) + (a[i+2][k+4] * b[k+3][j+2]) + (a[i+3][k+4] * b[k+3][j+3]) + (a[i+4][k+4] * b[k+3][j+4]) + (a[i+5][k+4] * b[k+3][j+5]) + (a[i+6][k+4] * b[k+3][j+6]) + (a[i+7][k+4] * b[k+3][j+7]));
							prod[i+3][j+3] += ((a[i][k+4] * b[k+4][j]) + (a[i+1][k+4] * b[k+4][j+1]) + (a[i+2][k+4] * b[k+4][j+2]) + (a[i+3][k+4] * b[k+4][j+3]) + (a[i+4][k+4] * b[k+4][j+4]) + (a[i+5][k+4] * b[k+4][j+5]) + (a[i+6][k+4] * b[k+4][j+6]) + (a[i+7][k+4] * b[k+4][j+7]));
							prod[i+3][j+2] += ((a[i][k+4] * b[k+5][j]) + (a[i+1][k+4] * b[k+5][j+1]) + (a[i+2][k+4] * b[k+5][j+2]) + (a[i+3][k+4] * b[k+5][j+3]) + (a[i+4][k+4] * b[k+5][j+4]) + (a[i+5][k+4] * b[k+5][j+5]) + (a[i+6][k+4] * b[k+5][j+6]) + (a[i+7][k+4] * b[k+5][j+7]));
							prod[i+3][j+1] += ((a[i][k+4] * b[k+6][j]) + (a[i+1][k+4] * b[k+6][j+1]) + (a[i+2][k+4] * b[k+6][j+2]) + (a[i+3][k+4] * b[k+6][j+3]) + (a[i+4][k+4] * b[k+6][j+4]) + (a[i+5][k+4] * b[k+6][j+5]) + (a[i+6][k+4] * b[k+6][j+6]) + (a[i+7][k+4] * b[k+6][j+7]));
							prod[i+3][j]   += ((a[i][k+4] * b[k+7][j]) + (a[i+1][k+4] * b[k+7][j+1]) + (a[i+2][k+4] * b[k+7][j+2]) + (a[i+3][k+4] * b[k+7][j+3]) + (a[i+4][k+4] * b[k+7][j+4]) + (a[i+5][k+4] * b[k+7][j+5]) + (a[i+6][k+4] * b[k+7][j+6]) + (a[i+7][k+4] * b[k+7][j+7]));

							prod[i+2][j+7] += ((a[i][k+5] * b[k][j])   + (a[i+1][k+5] * b[k][j+1])   + (a[i+2][k+5] * b[k][j+2])   + (a[i+3][k+5] * b[k][j+3])   + (a[i+4][k+5] * b[k][j+4])   + (a[i+5][k+5] * b[k][j+5])   + (a[i+6][k+5] * b[k][j+6])   + (a[i+7][k+5] * b[k][j+7]));
							prod[i+2][j+6] += ((a[i][k+5] * b[k+1][j]) + (a[i+1][k+5] * b[k+1][j+1]) + (a[i+2][k+5] * b[k+1][j+2]) + (a[i+3][k+5] * b[k+1][j+3]) + (a[i+4][k+5] * b[k+1][j+4]) + (a[i+5][k+5] * b[k+1][j+5]) + (a[i+6][k+5] * b[k+1][j+6]) + (a[i+7][k+5] * b[k+1][j+7]));
							prod[i+2][j+5] += ((a[i][k+5] * b[k+2][j]) + (a[i+1][k+5] * b[k+2][j+1]) + (a[i+2][k+5] * b[k+2][j+2]) + (a[i+3][k+5] * b[k+2][j+3]) + (a[i+4][k+5] * b[k+2][j+4]) + (a[i+5][k+5] * b[k+2][j+5]) + (a[i+6][k+5] * b[k+2][j+6]) + (a[i+7][k+5] * b[k+2][j+7]));
							prod[i+2][j+4] += ((a[i][k+5] * b[k+3][j]) + (a[i+1][k+5] * b[k+3][j+1]) + (a[i+2][k+5] * b[k+3][j+2]) + (a[i+3][k+5] * b[k+3][j+3]) + (a[i+4][k+5] * b[k+3][j+4]) + (a[i+5][k+5] * b[k+3][j+5]) + (a[i+6][k+5] * b[k+3][j+6]) + (a[i+7][k+5] * b[k+3][j+7]));
							prod[i+2][j+3] += ((a[i][k+5] * b[k+4][j]) + (a[i+1][k+5] * b[k+4][j+1]) + (a[i+2][k+5] * b[k+4][j+2]) + (a[i+3][k+5] * b[k+4][j+3]) + (a[i+4][k+5] * b[k+4][j+4]) + (a[i+5][k+5] * b[k+4][j+5]) + (a[i+6][k+5] * b[k+4][j+6]) + (a[i+7][k+5] * b[k+4][j+7]));
							prod[i+2][j+2] += ((a[i][k+5] * b[k+5][j]) + (a[i+1][k+5] * b[k+5][j+1]) + (a[i+2][k+5] * b[k+5][j+2]) + (a[i+3][k+5] * b[k+5][j+3]) + (a[i+4][k+5] * b[k+5][j+4]) + (a[i+5][k+5] * b[k+5][j+5]) + (a[i+6][k+5] * b[k+5][j+6]) + (a[i+7][k+5] * b[k+5][j+7]));
							prod[i+2][j+1] += ((a[i][k+5] * b[k+6][j]) + (a[i+1][k+5] * b[k+6][j+1]) + (a[i+2][k+5] * b[k+6][j+2]) + (a[i+3][k+5] * b[k+6][j+3]) + (a[i+4][k+5] * b[k+6][j+4]) + (a[i+5][k+5] * b[k+6][j+5]) + (a[i+6][k+5] * b[k+6][j+6]) + (a[i+7][k+5] * b[k+6][j+7]));
							prod[i+2][j]   += ((a[i][k+5] * b[k+7][j]) + (a[i+1][k+5] * b[k+7][j+1]) + (a[i+2][k+5] * b[k+7][j+2]) + (a[i+3][k+5] * b[k+7][j+3]) + (a[i+4][k+5] * b[k+7][j+4]) + (a[i+5][k+5] * b[k+7][j+5]) + (a[i+6][k+5] * b[k+7][j+6]) + (a[i+7][k+5] * b[k+7][j+7]));

							prod[i+1][j+7] += ((a[i][k+6] * b[k][j])   + (a[i+1][k+6] * b[k][j+1])   + (a[i+2][k+6] * b[k][j+2])   + (a[i+3][k+6] * b[k][j+3])   + (a[i+4][k+6] * b[k][j+4])   + (a[i+5][k+6] * b[k][j+5])   + (a[i+6][k+6] * b[k][j+6])   + (a[i+7][k+6] * b[k][j+7]));
							prod[i+1][j+6] += ((a[i][k+6] * b[k+1][j]) + (a[i+1][k+6] * b[k+1][j+1]) + (a[i+2][k+6] * b[k+1][j+2]) + (a[i+3][k+6] * b[k+1][j+3]) + (a[i+4][k+6] * b[k+1][j+4]) + (a[i+5][k+6] * b[k+1][j+5]) + (a[i+6][k+6] * b[k+1][j+6]) + (a[i+7][k+6] * b[k+1][j+7]));
							prod[i+1][j+5] += ((a[i][k+6] * b[k+2][j]) + (a[i+1][k+6] * b[k+2][j+1]) + (a[i+2][k+6] * b[k+2][j+2]) + (a[i+3][k+6] * b[k+2][j+3]) + (a[i+4][k+6] * b[k+2][j+4]) + (a[i+5][k+6] * b[k+2][j+5]) + (a[i+6][k+6] * b[k+2][j+6]) + (a[i+7][k+6] * b[k+2][j+7]));
							prod[i+1][j+4] += ((a[i][k+6] * b[k+3][j]) + (a[i+1][k+6] * b[k+3][j+1]) + (a[i+2][k+6] * b[k+3][j+2]) + (a[i+3][k+6] * b[k+3][j+3]) + (a[i+4][k+6] * b[k+3][j+4]) + (a[i+5][k+6] * b[k+3][j+5]) + (a[i+6][k+6] * b[k+3][j+6]) + (a[i+7][k+6] * b[k+3][j+7]));
							prod[i+1][j+3] += ((a[i][k+6] * b[k+4][j]) + (a[i+1][k+6] * b[k+4][j+1]) + (a[i+2][k+6] * b[k+4][j+2]) + (a[i+3][k+6] * b[k+4][j+3]) + (a[i+4][k+6] * b[k+4][j+4]) + (a[i+5][k+6] * b[k+4][j+5]) + (a[i+6][k+6] * b[k+4][j+6]) + (a[i+7][k+6] * b[k+4][j+7]));
							prod[i+1][j+2] += ((a[i][k+6] * b[k+5][j]) + (a[i+1][k+6] * b[k+5][j+1]) + (a[i+2][k+6] * b[k+5][j+2]) + (a[i+3][k+6] * b[k+5][j+3]) + (a[i+4][k+6] * b[k+5][j+4]) + (a[i+5][k+6] * b[k+5][j+5]) + (a[i+6][k+6] * b[k+5][j+6]) + (a[i+7][k+6] * b[k+5][j+7]));
							prod[i+1][j+1] += ((a[i][k+6] * b[k+6][j]) + (a[i+1][k+6] * b[k+6][j+1]) + (a[i+2][k+6] * b[k+6][j+2]) + (a[i+3][k+6] * b[k+6][j+3]) + (a[i+4][k+6] * b[k+6][j+4]) + (a[i+5][k+6] * b[k+6][j+5]) + (a[i+6][k+6] * b[k+6][j+6]) + (a[i+7][k+6] * b[k+6][j+7]));
							prod[i+1][j]   += ((a[i][k+6] * b[k+7][j]) + (a[i+1][k+6] * b[k+7][j+1]) + (a[i+2][k+6] * b[k+7][j+2]) + (a[i+3][k+6] * b[k+7][j+3]) + (a[i+4][k+6] * b[k+7][j+4]) + (a[i+5][k+6] * b[k+7][j+5]) + (a[i+6][k+6] * b[k+7][j+6]) + (a[i+7][k+6] * b[k+7][j+7]));

							prod[i][j+7] += ((a[i][k+7] * b[k][j])   + (a[i+1][k+7] * b[k][j+1])   + (a[i+2][k+7] * b[k][j+2])   + (a[i+3][k+7] * b[k][j+3])   + (a[i+4][k+7] * b[k][j+4])   + (a[i+5][k+7] * b[k][j+5])   + (a[i+6][k+7] * b[k][j+6])   + (a[i+7][k+7] * b[k][j+7]));
							prod[i][j+6] += ((a[i][k+7] * b[k+1][j]) + (a[i+1][k+7] * b[k+1][j+1]) + (a[i+2][k+7] * b[k+1][j+2]) + (a[i+3][k+7] * b[k+1][j+3]) + (a[i+4][k+7] * b[k+1][j+4]) + (a[i+5][k+7] * b[k+1][j+5]) + (a[i+6][k+7] * b[k+1][j+6]) + (a[i+7][k+7] * b[k+1][j+7]));
							prod[i][j+5] += ((a[i][k+7] * b[k+2][j]) + (a[i+1][k+7] * b[k+2][j+1]) + (a[i+2][k+7] * b[k+2][j+2]) + (a[i+3][k+7] * b[k+2][j+3]) + (a[i+4][k+7] * b[k+2][j+4]) + (a[i+5][k+7] * b[k+2][j+5]) + (a[i+6][k+7] * b[k+2][j+6]) + (a[i+7][k+7] * b[k+2][j+7]));
							prod[i][j+4] += ((a[i][k+7] * b[k+3][j]) + (a[i+1][k+7] * b[k+3][j+1]) + (a[i+2][k+7] * b[k+3][j+2]) + (a[i+3][k+7] * b[k+3][j+3]) + (a[i+4][k+7] * b[k+3][j+4]) + (a[i+5][k+7] * b[k+3][j+5]) + (a[i+6][k+7] * b[k+3][j+6]) + (a[i+7][k+7] * b[k+3][j+7]));
							prod[i][j+3] += ((a[i][k+7] * b[k+4][j]) + (a[i+1][k+7] * b[k+4][j+1]) + (a[i+2][k+7] * b[k+4][j+2]) + (a[i+3][k+7] * b[k+4][j+3]) + (a[i+4][k+7] * b[k+4][j+4]) + (a[i+5][k+7] * b[k+4][j+5]) + (a[i+6][k+7] * b[k+4][j+6]) + (a[i+7][k+7] * b[k+4][j+7]));
							prod[i][j+2] += ((a[i][k+7] * b[k+5][j]) + (a[i+1][k+7] * b[k+5][j+1]) + (a[i+2][k+7] * b[k+5][j+2]) + (a[i+3][k+7] * b[k+5][j+3]) + (a[i+4][k+7] * b[k+5][j+4]) + (a[i+5][k+7] * b[k+5][j+5]) + (a[i+6][k+7] * b[k+5][j+6]) + (a[i+7][k+7] * b[k+5][j+7]));
							prod[i][j+1] += ((a[i][k+7] * b[k+6][j]) + (a[i+1][k+7] * b[k+6][j+1]) + (a[i+2][k+7] * b[k+6][j+2]) + (a[i+3][k+7] * b[k+6][j+3]) + (a[i+4][k+7] * b[k+6][j+4]) + (a[i+5][k+7] * b[k+6][j+5]) + (a[i+6][k+7] * b[k+6][j+6]) + (a[i+7][k+7] * b[k+6][j+7]));
							prod[i][j]   += ((a[i][k+7] * b[k+7][j]) + (a[i+1][k+7] * b[k+7][j+1]) + (a[i+2][k+7] * b[k+7][j+2]) + (a[i+3][k+7] * b[k+7][j+3]) + (a[i+4][k+7] * b[k+7][j+4]) + (a[i+5][k+7] * b[k+7][j+5]) + (a[i+6][k+7] * b[k+7][j+6]) + (a[i+7][k+7] * b[k+7][j+7]));
						}
					}
				}
			}
		}
		else if (a_rows_b_cols % 4 == 0)
		{
			// Iterate over the rows of the A matrix
			for (int i = 0; i < IN_A_ROWS; i += 4) // Row
			{
				// Iterate over the columns of the B matrix
				for (int j = 0; j < IN_B_COLS; j += 4) // Col
				{
					prod[i][j] = 0;
					prod[i][j+1] = 0;
					prod[i][j+2] = 0;
					prod[i][j+3] = 0;
					prod[i+1][j+1] = 0;
					prod[i+1][j] = 0;
					prod[i+1][j+2] = 0;
					prod[i+1][j+3] = 0;
					prod[i+2][j+1] = 0;
					prod[i+2][j+2] = 0;
					prod[i+2][j+3] = 0;
					prod[i+2][j] = 0;
					prod[i+3][j] = 0;
					prod[i+3][j+1] = 0;
					prod[i+3][j+2] = 0;
					prod[i+3][j+3] = 0;

					// Do the inner product of a row of A and column of B
					for (k = l; k < IN_B_ROWS; k += 4) // Product
					{
						if (k < a_rows_b_cols)
						{
							prod[i+3][j+3] += ((a[i][k] * b[k][j]) + (a[i+1][k] * b[k][j+1]) + (a[i+2][k] * b[k][j+2]) + (a[i+3][k] * b[k][j+3]));
							prod[i+3][j+2] += ((a[i][k] * b[k+1][j]) + (a[i+1][k] * b[k+1][j+1]) + (a[i+2][k] * b[k+1][j+2]) + (a[i+3][k] * b[k+1][j+3]));
							prod[i+3][j+1] += ((a[i][k] * b[k+2][j]) + (a[i+1][k] * b[k+2][j+1]) + (a[i+2][k] * b[k+2][j+2]) + (a[i+3][k] * b[k+2][j+3]));
							prod[i+3][j]   += ((a[i][k] * b[k+3][j]) + (a[i+1][k] * b[k+3][j+1]) + (a[i+2][k] * b[k+3][j+2]) + (a[i+3][k] * b[k+3][j+3]));
							prod[i+2][j+3] += ((a[i][k+1] * b[k][j]) + (a[i+1][k+1] * b[k][j+1]) + (a[i+2][k+1] * b[k][j+2]) + (a[i+3][k+1] * b[k][j+3]));
							prod[i+2][j+2] += ((a[i][k+1] * b[k+1][j]) + (a[i+1][k+1] * b[k+1][j+1]) + (a[i+2][k+1] * b[k+1][j+2]) + (a[i+3][k+1] * b[k+1][j+3]));
							prod[i+2][j+1] += ((a[i][k+1] * b[k+2][j]) + (a[i+1][k+1] * b[k+2][j+1]) + (a[i+2][k+1] * b[k+2][j+2]) + (a[i+3][k+1] * b[k+2][j+3]));
							prod[i+2][j]   += ((a[i][k+1] * b[k+3][j]) + (a[i+1][k+1] * b[k+3][j+1]) + (a[i+2][k+1] * b[k+3][j+2]) + (a[i+3][k+1] * b[k+3][j+3]));
							prod[i+1][j+3] += ((a[i][k+2] * b[k][j]) + (a[i+1][k+2] * b[k][j+1]) + (a[i+2][k+2] * b[k][j+2]) + (a[i+3][k+2] * b[k][j+3]));
							prod[i+1][j+2] += ((a[i][k+2] * b[k+1][j]) + (a[i+1][k+2] * b[k+1][j+1]) + (a[i+2][k+2] * b[k+1][j+2]) + (a[i+3][k+2] * b[k+1][j+3]));
							prod[i+1][j+1] += ((a[i][k+2] * b[k+2][j]) + (a[i+1][k+2] * b[k+2][j+1]) + (a[i+2][k+2] * b[k+2][j+2]) + (a[i+3][k+2] * b[k+2][j+3]));
							prod[i+1][j]   += ((a[i][k+2] * b[k+3][j]) + (a[i+1][k+2] * b[k+3][j+1]) + (a[i+2][k+2] * b[k+3][j+2]) + (a[i+3][k+2] * b[k+3][j+3]));
							prod[i][j+3]   += ((a[i][k+3] * b[k][j]) + (a[i+1][k+3] * b[k][j+1]) + (a[i+2][k+3] * b[k][j+2]) + (a[i+3][k+3] * b[k][j+3]));
							prod[i][j+2]   += ((a[i][k+3] * b[k+1][j]) + (a[i+1][k+3] * b[k+1][j+1]) + (a[i+2][k+3] * b[k+1][j+2]) + (a[i+3][k+3] * b[k+1][j+3]));   
							prod[i][j+1]   += ((a[i][k+3] * b[k+2][j]) + (a[i+1][k+3] * b[k+2][j+1]) + (a[i+2][k+3] * b[k+2][j+2]) + (a[i+3][k+3] * b[k+2][j+3]));   
							prod[i][j]     += ((a[i][k+3] * b[k+3][j]) + (a[i+1][k+3] * b[k+3][j+1]) + (a[i+2][k+3] * b[k+3][j+2]) + (a[i+3][k+3] * b[k+3][j+3]));   
						}
					}
				}
			}
		}
		else if (a_rows_b_cols % 2 == 0)
		{
			// Iterate over the rows of the A matrix
			for (int i = 0; i < IN_A_ROWS; i += 2) // Row
			{
				// Iterate over the columns of the B matrix
				for (int j = 0; j < IN_B_COLS; j += 2) // Col
				{
					prod[i][j] = 0;
					prod[i+1][j] = 0;
					prod[i][j+1] = 0;
					prod[i+1][j+1] = 0;

					// Do the inner product of a row of A and column of B
					for (k = l; k < IN_B_ROWS; k += 2) // Product
					{
						if (k < a_rows_b_cols)
						{
							prod[i+1][j+1] += ((a[i][k] * b[k][j]) + (a[i+1][k] * b[k][j+1]));
							prod[i+1][j] += ((a[i][k] * b[k+1][j]) + (a[i+1][k] * b[k+1][j+1]));
							prod[i][j+1] += ((a[i][k+1] * b[k][j]) + (a[i+1][k+1] * b[k][j+1]));
							prod[i][j] += ((a[i][k+1] * b[k+1][j]) + (a[i+1][k+1] * b[k+1][j+1]));
						}
					}
				}
			}
		}
		else {
			// Iterate over the rows of the A matrix
			for (int i = 0; i < IN_A_ROWS; i++) // Row
			{
				// Iterate over the columns of the B matrix
				for (int j = 0; j < IN_B_COLS; j++) // Col
				{
					prod[i][j] = 0;
					// Do the inner product of a row of A and column of B
					for (k; k < IN_B_ROWS; k++) // Product
					{
						if (k < a_rows_b_cols)
						{
							prod[i][j] += a[i][k] * b[k][j];

						}
					}
				}
			}
		}
}

