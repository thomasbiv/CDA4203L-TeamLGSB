// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2021.2 (64-bit)
// Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
// ==============================================================
// control
// 0x00000 : Control signals
//           bit 0  - ap_start (Read/Write/COH)
//           bit 1  - ap_done (Read/COR)
//           bit 2  - ap_idle (Read)
//           bit 3  - ap_ready (Read/COR)
//           bit 7  - auto_restart (Read/Write)
//           others - reserved
// 0x00004 : Global Interrupt Enable Register
//           bit 0  - Global Interrupt Enable (Read/Write)
//           others - reserved
// 0x00008 : IP Interrupt Enable Register (Read/Write)
//           bit 0 - enable ap_done interrupt (Read/Write)
//           bit 1 - enable ap_ready interrupt (Read/Write)
//           bit 5 - enable ap_local_deadlock interrupt (Read/Write)
//           others - reserved
// 0x0000c : IP Interrupt Status Register (Read/TOW)
//           bit 0 - ap_done (COR/TOW)
//           bit 1 - ap_ready (COR/TOW)
//           bit 5 - ap_local_deadlock (COR/TOW)
//           others - reserved
// 0x00010 : Data signal of a_row_b_col
//           bit 31~0 - a_row_b_col[31:0] (Read/Write)
// 0x00014 : reserved
// 0x40000 ~
// 0x7ffff : Memory 'a' (65536 * 32b)
//           Word n : bit [31:0] - a[n]
// 0x80000 ~
// 0xbffff : Memory 'b' (65536 * 32b)
//           Word n : bit [31:0] - b[n]
// 0xc0000 ~
// 0xfffff : Memory 'prod' (65536 * 32b)
//           Word n : bit [31:0] - prod[n]
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XMATRIX_MULT_CONTROL_ADDR_AP_CTRL          0x00000
#define XMATRIX_MULT_CONTROL_ADDR_GIE              0x00004
#define XMATRIX_MULT_CONTROL_ADDR_IER              0x00008
#define XMATRIX_MULT_CONTROL_ADDR_ISR              0x0000c
#define XMATRIX_MULT_CONTROL_ADDR_A_ROW_B_COL_DATA 0x00010
#define XMATRIX_MULT_CONTROL_BITS_A_ROW_B_COL_DATA 32
#define XMATRIX_MULT_CONTROL_ADDR_A_BASE           0x40000
#define XMATRIX_MULT_CONTROL_ADDR_A_HIGH           0x7ffff
#define XMATRIX_MULT_CONTROL_WIDTH_A               32
#define XMATRIX_MULT_CONTROL_DEPTH_A               65536
#define XMATRIX_MULT_CONTROL_ADDR_B_BASE           0x80000
#define XMATRIX_MULT_CONTROL_ADDR_B_HIGH           0xbffff
#define XMATRIX_MULT_CONTROL_WIDTH_B               32
#define XMATRIX_MULT_CONTROL_DEPTH_B               65536
#define XMATRIX_MULT_CONTROL_ADDR_PROD_BASE        0xc0000
#define XMATRIX_MULT_CONTROL_ADDR_PROD_HIGH        0xfffff
#define XMATRIX_MULT_CONTROL_WIDTH_PROD            32
#define XMATRIX_MULT_CONTROL_DEPTH_PROD            65536

