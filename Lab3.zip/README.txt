All relevant Verilog modules are contained within the folder "Code Files".
Open in ISE (or notepad) to verify them.